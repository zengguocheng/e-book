﻿《算法竞赛入门经典》第二版 范例代码

刘汝佳

第三章

例题

注：所有代码都可以用C99和C++编译，为了和后面统一，后缀名均为cpp

3-1. UVa272 Tex Quotes

3-2. UVa10082 WERTYU

3-3. UVa401 Palindromes

3-4. UVa340 Master-Mind Hints

3-5. UVa1583 Digit Generator

3-6. UVa1584 Circular Sequence
