﻿《算法竞赛入门经典》第二版 范例代码

刘汝佳

第五章

知识点

point.cpp       - 结构体的更多用法

template.cpp    - 用模板函数sum计算结构体Point数组的各元素和

point2.cpp      - 模板类Point，以及int型Point和double型Point

pq.cpp          - 优先队列测试

test_stl.cpp    - 测试STL

test_stream.cpp - 测试sstream

5-*.cpp         - 正文中的简短代码

例题代码

5-1 UVa10474 Where is the Marble?

5-2 UVa101 The Blocks Problem

5-3 UVa10815 Andy's First Dictionary

5-4 UVa156 Ananagrams

5-5 UVa12096 The SetStack Computer

5-6 UVa540 Team Queue

5-7 UVa136 Ugly Numbers

5-8 UVa400 Unix ls

5-9 UVa1592 Database

5-10 UVa207 PGA Tour Prize Money

5-11 UVa814 The Letter Carrier's Rounds

5-12 UVa221 Urban Elevations

输入输出数据

UVa12096  (官方数据)
