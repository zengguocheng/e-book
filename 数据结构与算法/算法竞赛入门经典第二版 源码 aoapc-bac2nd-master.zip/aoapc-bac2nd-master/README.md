aoapc-bac2nd
============

Source codes for book &lt;&lt;&lt;BeginningAlgorithmContests>> Second edition

Where to buy the book?

http://item.jd.com/11469701.html

Though the book is in Chinese only, examples and exercises can be submitted to UVa:

http://uva.onlinejudge.org/index.php?option=com_onlinejudge&Itemid=8&category=827

Current Status
==============

Chapter 3: 6/6

Chapter 4: 6/6

Chapter 5: 12/12

Chapter 6: 22/22

Chapter 7: 15/15

Chapter 8: 19/19

Chapter 9: 31/31

Chapter 10: 29/29

Chapter 11: 15/15

Chapter 12: 4/37

Only chapter 12 is not finished. However, problems in this chapter is considerably more difficult,

so they'll be filled VERY slowly. Sorry.
